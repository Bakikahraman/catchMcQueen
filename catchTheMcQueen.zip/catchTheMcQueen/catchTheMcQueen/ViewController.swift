//
//  ViewController.swift
//  catchTheMcQueen
//
//  Created by baki on 9.08.2022.
//

import UIKit

class ViewController: UIViewController {
// vars
    var score = 0
    var timer = Timer()
    var counter = 0
    var mcArray = [UIImageView]()
    var hideTimer = Timer()
    var highScore = 0
    
    
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var highScoreLabel: UILabel!
    @IBOutlet weak var mc1: UIImageView!
    @IBOutlet weak var mc2: UIImageView!
    @IBOutlet weak var mc3: UIImageView!
    @IBOutlet weak var mc4: UIImageView!
    @IBOutlet weak var mc5: UIImageView!
    @IBOutlet weak var mc6: UIImageView!
    @IBOutlet weak var mc7: UIImageView!
    @IBOutlet weak var mc8: UIImageView!
    @IBOutlet weak var mc9: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        
//        timer
        counter = 15
        timeLabel.text = " \(counter)"
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(countDown), userInfo: nil, repeats: true)
        
        hideTimer = Timer.scheduledTimer(timeInterval: 0.8, target: self, selector: #selector(hideMc), userInfo: nil, repeats: true)
        
        
        scoreLabel.text = "Score: \(score) "
        
        let storedHighScore = UserDefaults.standard.object(forKey: "highscore")
        
        if storedHighScore == nil {
            highScore = 0
            highScoreLabel.text = "Highscore: \(highScore)"
            }
        if let newScore = storedHighScore as? Int {
            highScore = newScore
            highScoreLabel.text = "Highscore: \(highScore)"
        }
        
        
        
//        image
        mc1.isUserInteractionEnabled = true
        mc2.isUserInteractionEnabled = true
        mc3.isUserInteractionEnabled = true
        mc4.isUserInteractionEnabled = true
        mc5.isUserInteractionEnabled = true
        mc6.isUserInteractionEnabled = true
        mc7.isUserInteractionEnabled = true
        mc8.isUserInteractionEnabled = true
        mc9.isUserInteractionEnabled = true

        
        let recoginezer1 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer2 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer3 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer4 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer5 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer6 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer7 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer8 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        let recoginezer9 = UITapGestureRecognizer(target: self, action: #selector(increaseScore))
        
        mc1.addGestureRecognizer(recoginezer1)
        mc2.addGestureRecognizer(recoginezer2)
        mc3.addGestureRecognizer(recoginezer3)
        mc4.addGestureRecognizer(recoginezer4)
        mc5.addGestureRecognizer(recoginezer5)
        mc6.addGestureRecognizer(recoginezer6)
        mc7.addGestureRecognizer(recoginezer7)
        mc8.addGestureRecognizer(recoginezer8)
        mc9.addGestureRecognizer(recoginezer9)

        mcArray = [mc1, mc2, mc3, mc4, mc5, mc6, mc7, mc8, mc9]
     
        
        hideMc()
            
        }
    
   
    
    
    
       @objc func hideMc() {
        for mc in mcArray {
            
            mc.isHidden = true
        }
        let random = Int(arc4random_uniform(UInt32(mcArray.count - 1)))
        mcArray[random].isHidden = false
        
          
           }
           
        
    
    
        @objc func increaseScore() {
            
            score += 1
            scoreLabel.text = "Score: \(score)"

    }
   
        @objc func countDown(){
        counter -= 1
        timeLabel.text = String(counter)
        
        if counter == 0 {
            timer.invalidate()
            hideTimer.invalidate()
            
            for mc in mcArray {
                
                mc.isHidden = true
                }
            
                if self.score > self.highScore{
                    self.highScore = self.score
                    highScoreLabel.text = "High score: \(self.highScore)"
                    
                    UserDefaults.standard.set(self.highScore, forKey: "highscore")
                
            }
//            alert
            let alert = UIAlertController(title: "GAME OVER", message: "play again ?", preferredStyle: UIAlertController.Style.alert)
            let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler: nil)
            let replaybutton = UIAlertAction(title: "Replay", style: UIAlertAction.Style.default) {  UIAlertAction in
                
                
//                replay func
                self.score = 0
                self.scoreLabel.text = "Score: \(self.score)"
                self.counter = 15
                self.timeLabel.text = String(self.counter)
                
                
                self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.countDown), userInfo: nil, repeats: true)
                
                self.hideTimer = Timer.scheduledTimer(timeInterval: 0.8, target: self, selector: #selector(self.hideMc), userInfo: nil, repeats: true)
                
                
            }
            
            alert.addAction(okButton)
            alert.addAction(replaybutton)
            self.present(alert, animated: true, completion: nil)
        }
        
        
        
    }


}

